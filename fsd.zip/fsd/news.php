<?php
/**
* news and comments view section
*/

// define root directory
define('ROOT', __DIR__);

/**
* call once class NewsManager
*/
require_once(ROOT . '/utils/NewsManager.php');
/**
* call once class CommentManager
*/
require_once(ROOT . '/utils/CommentManager.php');

// create new instance of class NewsManager
$newsmanager = new NewsManager();
// create new instance of class CommentManager
$commentManager = new CommentManager();

// json variable object
$newslist = array();
$x = 0;
// change getInstance() functions in loop to new class variable 
foreach ($newsmanager->listNews() as $news) {
	$newsitem = new stdClass();
	// pass value to json object
	$newsitem->id = $x;
	$newsitem->title = $news->getTitle();
	$newsitem->text = $news->getBody();
	$commentlist = array();
	foreach ($commentManager->listComments() as $comment) {
		$commentitem = new stdClass();
		if ($comment->getNewsId() == $news->getId()) {
			$commentitem->id =  $comment->getId();
			$commentitem->text = $comment->getBody();
			$commentlist[] = $commentitem;
		}
	}
	$newsitem->comment = "";
	$newslist[] = $newsitem;
	$x++;
}

$newslist = json_encode($newslist);

echo $newslist;
// unused $c variable, should be deleted.
//$c = $commentManager->listComments();

?>