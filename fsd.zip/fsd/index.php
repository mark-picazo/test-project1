<?php
/**
* main index file of FSD Technical Exam
*/

/*
* defines ROOT as a global constant for root directory starting with index.php main folder 
*/
define('ROOT', __DIR__);

include "views/header.php";
include "views/main.php";
include "views/footer.php";
?>