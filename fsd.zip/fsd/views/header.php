<html>
<head>
	<meta charset="UTF-8">
	<title>{{title}}</title>
	<script src="https://unpkg.com/vue"></script>
</head>
<body>