<div id="main">
	<div id="news-list">
		<news-section v-for="item in news"
			v-bind:item="item"
			v-bind:key="item.id">
		</news-section>
	</div>
</div>

<script type="text/javascript">


function getNews(){
	var news_arr;
	var return_arr = [];

	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
           news_arr = this.responseText;          
        }
    };
    xmlhttp.open("GET", "./news.php", true);
    xmlhttp.send();
  
    return news_arr;
}

Vue.component('news-section', {
  props: ['item'],
  template: '\
  			<span>\
  			<h1>{{ item.title }}</h1>\
  			<p>{{ item.text }}</p>\
  			</span>'
})

var title = new Vue({
	el: 'title',
	data: {
    	title: "News and Comments Section"
  	}  
})

var news_list = new Vue({
	el: '#news-list',
	data: {
	  	news: getNews(),
	}
})


</script>