<?php
/*
* class CommentManager to manage the comment feature for each news 
*/
class CommentManager
{
	// for flexibility and robustness, better to avoid null variables
	// private static $instance = null;

	// variable for class DB instance
	private $db;

	public function __construct()
	{
		require_once(ROOT . '/utils/DB.php');
		require_once(ROOT . '/class/Comment.php');

		// instantiate class DB
		$this->db = new DB();
	}

	// instatiate a new class using variable for better flexibility
	// public static function getInstance()
	// {
	// 	if (null === self::$instance) {
	// 		$c = __CLASS__;
	// 		self::$instance = new $c;
	// 	}
	// 	return self::$instance;
	// }

	public function listComments()
	{
		$comments = [];

		// add error handling
		try {
			$rows = $this->db->select('SELECT * FROM `comment`');
			
			foreach($rows as $row) {
				// instantiate class Comment
				$n = new Comment();
				$comments[] = $n->setId($row['id'])
				  ->setBody($row['body'])
				  ->setCreatedAt($row['created_at'])
				  ->setNewsId($row['news_id']);
			}
		} catch (PDOException $e) { }

		return $comments;
	}

	public function addCommentForNews($body, $newsId)
	{
		// should be refactored to handle sql injections
		$sql = "INSERT INTO `comment` (`body`, `created_at`, `news_id`) VALUES('". $body . "','" . date('Y-m-d') . "','" . $newsId . "')";
		$this->db->exec($sql);
		return $this->db->lastInsertId($sql);
	}

	public function deleteComment($id)
	{
		// should be refactored to handle sql injections
		$sql = "DELETE FROM `comment` WHERE `id`=" . $id;
		return $this->db->exec($sql);
	}
}