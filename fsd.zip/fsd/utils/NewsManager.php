<?php
/*
* class NewsManager to manage the news feature 
*/
class NewsManager
{
	// for flexibility and robustness, better to avoid null variables
	// private static $instance = null;

	// variable for class DB instance
	private $db;

	public function __construct()
	{
		require_once(ROOT . '/utils/DB.php');
		require_once(ROOT . '/utils/CommentManager.php');
		require_once(ROOT . '/class/News.php');

		// instantiate class DB
		$this->db = new DB();
	}

	// instatiate a new class using variable for better flexibility
	// public static function getInstance()
	// {
	// 	if (null === self::$instance) {
	// 		$c = __CLASS__;
	// 		self::$instance = new $c;
	// 	}
	// 	return self::$instance;
	// }

	/**
	* list all news
	*/
	public function listNews()
	{
		$news = [];

		// add error handling
		try {			
			$rows = $this->db->select('SELECT * FROM `news`');
			
			foreach($rows as $row) {
				// instantiate class News
				$n = new News();
				$news[] = $n->setId($row['id'])
				  ->setTitle($row['title'])
				  ->setBody($row['body'])
				  ->setCreatedAt($row['created_at']);
			}
		} catch (PDOException $e) { }

		return $news;
	}

	/**
	* add a record in news table
	*/
	public function addNews($title, $body)
	{	
		// should be refactored to handle sql injections
		$sql = "INSERT INTO `news` (`title`, `body`, `created_at`) VALUES('". $title . "','" . $body . "','" . date('Y-m-d') . "')";
		$this->db->exec($sql);
		return $this->db->lastInsertId($sql);
	}

	/**
	* deletes a news, and also linked comments
	*/
	public function deleteNews($id)
	{
		//instantiate class CommentManager
		$commentManager = new CommentManager();
		$comments = $commentManager->listComments();
		$idsToDelete = [];

		foreach ($comments as $comment) {
			if ($comment->getNewsId() == $id) {
				$idsToDelete[] = $comment->getId();
			}
		}

		foreach($idsToDelete as $id) {
			$commentManager->deleteComment($id);
		}

		// should be refactored to handle sql injections
		$sql = "DELETE FROM `news` WHERE `id`=" . $id;
		return $this->db->exec($sql);
	}
}